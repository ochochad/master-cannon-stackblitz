import React, { useState } from 'react'

export default function InventoryLauncher() {
  const [equippedItem, setEquippedItem] = useState(null)

  const inventoryItems = [
    { id: 1, name: 'Chrome Saber', type: 'Weapon', rarity: 'Legendary' },
    { id: 2, name: 'Void Cloak', type: 'Armor', rarity: 'Rare' }
  ]

  const handleEquip = (item) => {
    setEquippedItem(item)
  }

  return (
    <div style={{ marginTop: '1rem', padding: '1rem', background: '#2a2a3f' }}>
      <h2>Inventory</h2>
      <ul>
        {inventoryItems.map(item => (
          <li
            key={item.id}
            onClick={() => handleEquip(item)}
            style={{
              cursor: 'pointer',
              padding: '0.5rem',
              backgroundColor: '#3a3a4f',
              marginBottom: '0.5rem',
              borderRadius: '4px'
            }}
          >
            🧩 {item.name} — <em>{item.rarity}</em>
          </li>
        ))}
      </ul>

      {equippedItem && (
        <div style={{ marginTop: '1rem' }}>
          <strong>Equipped:</strong> {equippedItem.name} ({equippedItem.type})
        </div>
      )}
    </div>
  )
}
