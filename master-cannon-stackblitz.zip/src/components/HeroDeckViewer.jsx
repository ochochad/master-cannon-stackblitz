import React from 'react'

export default function HeroDeckViewer() {
  return (
    <div style={{ marginTop: '1rem', padding: '1rem', background: '#2a2a3f' }}>
      <h2>Hero Deck</h2>
      <p>Browse your hero cards here.</p>
    </div>
  )
}
