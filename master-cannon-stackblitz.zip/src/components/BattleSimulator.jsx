import React from 'react'

export default function BattleSimulator() {
  return (
    <div style={{ marginTop: '1rem', padding: '1rem', background: '#2a2a3f' }}>
      <h2>Battle Simulator</h2>
      <p>Run test encounters and simulations.</p>
    </div>
  )
}
