import React from 'react'
import InventoryLauncher from './InventoryLauncher'
import HeroDeckViewer from './HeroDeckViewer'
import BattleSimulator from './BattleSimulator'

export default function Layout() {
  return (
    <div style={{ padding: '2rem', color: 'white', background: '#1e1e2f' }}>
      <h1>Master Cannon Universe</h1>
      <p>Welcome to the multiverse battle simulator.</p>
      <InventoryLauncher />
      <HeroDeckViewer />
      <BattleSimulator />
    </div>
  )
}
